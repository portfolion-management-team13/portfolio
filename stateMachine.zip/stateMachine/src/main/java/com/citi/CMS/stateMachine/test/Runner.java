package com.citi.CMS.stateMachine.test;

import com.citi.CMS.stateMachine.util.Events;
import com.citi.CMS.stateMachine.util.States;
import org.springframework.boot.CommandLineRunner;
import org.springframework.statemachine.StateMachine;

import javax.annotation.Resource;

public class Runner implements CommandLineRunner {

    @Resource
    StateMachine<States, Events> stateMachine;
    @Override
    public void run(String... args) throws Exception {
        stateMachine.start();
        stateMachine.sendEvent(Events.MAKER_PUBLISH);
        stateMachine.sendEvent(Events.NOTIFY_MAKER_CHECKER);
        stateMachine.sendEvent(Events.CHECKER_APPROVE);
        stateMachine.sendEvent(Events.CHECKER_REVIEW);
        stateMachine.sendEvent(Events.CHECKER_UNLOCK);
        stateMachine.sendEvent(Events.CHECKER_REVIEW);
        stateMachine.sendEvent(Events.CHECKER_EDIT);
        stateMachine.sendEvent(Events.CHECKER_REJECT);
        stateMachine.sendEvent(Events.NOTIFY_MAKER_CHECKER);
    }
}
