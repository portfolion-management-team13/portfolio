package com.citi.CMS.stateMachine.util;

public enum  States {
    DRAFT, // DRAFT not a data change status.
    AWAITING_CHECK,
    LOCKED,
    APPROVED,
    REJECTED
}
