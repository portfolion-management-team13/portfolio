package com.citi.CMS.stateMachine;

import com.citi.CMS.stateMachine.test.Runner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class StateMachineApplication {

	@Bean
	public Runner startupRunner() {
		return new Runner();
	}

	public static void main(String[] args) {
		SpringApplication.run(StateMachineApplication.class, args);
	}

}
