package com.citi.CMS.stateMachine.config;

import com.citi.CMS.stateMachine.util.Events;
import com.citi.CMS.stateMachine.util.States;
import org.springframework.context.annotation.Configuration;
import org.springframework.statemachine.config.EnableStateMachine;
import org.springframework.statemachine.config.EnumStateMachineConfigurerAdapter;
import org.springframework.statemachine.config.builders.StateMachineStateConfigurer;
import org.springframework.statemachine.config.builders.StateMachineTransitionConfigurer;

import java.util.EnumSet;

@Configuration
@EnableStateMachine
public class StateMachineConfig extends EnumStateMachineConfigurerAdapter<States, Events> {

    @Override
    public void configure(StateMachineStateConfigurer<States, Events> states) throws Exception {
        states.withStates().initial(States.DRAFT).states(EnumSet.allOf(States.class));
    }

    @Override
    public void configure(StateMachineTransitionConfigurer<States, Events> transitions) throws Exception {
        transitions.withExternal()
                .source(States.DRAFT).target(States.AWAITING_CHECK)
                .event(Events.MAKER_PUBLISH)
                .and()
                .withExternal()
                .source(States.AWAITING_CHECK).target(States.LOCKED)
                .event(Events.CHECKER_REVIEW)
                .and()
                .withExternal()
                .source(States.LOCKED).target(States.APPROVED)
                .event(Events.CHECKER_APPROVE)
                .and()
                .withExternal()
                .source(States.LOCKED).target(States.REJECTED)
                .event(Events.CHECKER_REJECT)
                .and()
                .withExternal()
                .source(States.LOCKED).target(States.LOCKED)
                .event(Events.CHECKER_EDIT)
                .and()
                .withExternal()
                .source(States.AWAITING_CHECK).target(States.AWAITING_CHECK)
                .event(Events.NOTIFY_MAKER_CHECKER)
                .and()
                .withExternal()
                .source(States.APPROVED).target(States.APPROVED)
                .event(Events.NOTIFY_MAKER_CHECKER)
                .and()
                .withExternal()
                .source(States.REJECTED).target(States.REJECTED)
                .event(Events.NOTIFY_MAKER_CHECKER)
                .and()
                .withExternal()
        .source(States.LOCKED).target(States.AWAITING_CHECK)
        .event(Events.CHECKER_UNLOCK);


                ;


    }


}
