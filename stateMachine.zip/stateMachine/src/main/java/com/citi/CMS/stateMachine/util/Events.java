package com.citi.CMS.stateMachine.util;

public enum Events {
    MAKER_PUBLISH,
    CHECKER_REVIEW,
    CHECKER_EDIT,
    CHECKER_APPROVE,
    CHECKER_REJECT,
    NOTIFY_MAKER_CHECKER,
    CHECKER_UNLOCK
}
