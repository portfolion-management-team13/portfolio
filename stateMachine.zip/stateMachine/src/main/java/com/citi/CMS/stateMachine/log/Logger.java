package com.citi.CMS.stateMachine.log;

public class Logger {
    public void info(String info){
        System.out.println(info);
    }
}
