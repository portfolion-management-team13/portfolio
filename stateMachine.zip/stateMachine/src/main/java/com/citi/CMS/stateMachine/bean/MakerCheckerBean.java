package com.citi.CMS.stateMachine.bean;

import com.citi.CMS.stateMachine.log.Logger;
import com.citi.CMS.stateMachine.util.States;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.statemachine.annotation.OnTransition;
import org.springframework.statemachine.annotation.WithStateMachine;

@WithStateMachine
@Data
@Slf4j
public class MakerCheckerBean {
    /*
    * @see Status
    * */

    private String status = States.DRAFT.name();
    private Logger log = new Logger();

    @OnTransition(source = "DRAFT",target = "AWAITING_CHECK")
    public void MakerPublish(){
        log.info("Maker sent request, current state:"+States.AWAITING_CHECK.name());
 //       this.status = States.AWAITING_CHECK.name();
    }

    @OnTransition(source = "AWAITING_CHECK",target = "LOCKED")
    public void CheckerReview(){
        log.info("Checker review publish request, current state:"+States.LOCKED.name());
///        this.status = States.LOCKED.name();
    }

    @OnTransition(source = "LOCKED",target = "APPROVED")
    public void CheckerApprove(){
      log.info("Checker review over, make desicion current state:"+States.APPROVED.name());
//      this.status = States.APPROVED.name();
    }

    @OnTransition(source = "LOCKED",target = "REJECTED")
    public void CheckerReject(){
        log.info("Checker review over, try to reject, current state: "+States.REJECTED.name());
  //      this.status = States.REJECTED.name();
    }

    @OnTransition(source = "LOCKED",target = "LOCKED")
    public void CheckerEdit(){
        log.info("Checker Edit Page, current state:"+States.LOCKED.name());
        this.status = States.LOCKED.name();
    }

    @OnTransition(source = "AWAITING_CHECK",target = "AWAITING_CHECK")
    public void NotifyMakerCheckerWhileRequestGenerated(){
        log.info("Request generated, notify maker checker, current state:"+States.AWAITING_CHECK.name());
        this.status = States.AWAITING_CHECK.name();
    }

    @OnTransition(source = "APPROVED",target = "APPROVED")
    public void NotifyMakerCheckerWhileRequestApprove(){
        log.info("Approved request, notify maker checker, current state:"+States.APPROVED.name());
        this.status = States.APPROVED.name();
    }

    @OnTransition(source = "REJECTED",target = "REJECTED")
    public void NotifyMakerCheckerWhileRequestReject(){
        log.info("Rejected request, notify maker checker, current state:: "+States.REJECTED.name());
        this.status = States.REJECTED.name();
    }

    @OnTransition(source = "LOCKED",target = "AWAITING_CHECK")
    public void CheckerUnlockChange(){
        log.info("Checker unlocked Request, current states: "+States.AWAITING_CHECK.name());
        this.status = States.REJECTED.name();
    }





}