package com.citi.CMS.stateMachine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StateMachineApplicationTests {

	@Test
	void contextLoads() {
	}

}
